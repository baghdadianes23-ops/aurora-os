#!/usr/bin/env python3
"""Aurora Squircle icon pack — one shape, one rim, one glow, for every icon."""
import math, os, sys

OUT = sys.argv[1] if len(sys.argv) > 1 else "icons/Aurora-Squircle"

def squircle(size=512, m=20, n=5.0, pts=96):
    r = (size - 2 * m) / 2; c = size / 2; d = []
    for i in range(pts):
        t = 2 * math.pi * i / pts
        ct, st = math.cos(t), math.sin(t)
        x = c + r * math.copysign(abs(ct) ** (2 / n), ct)
        y = c + r * math.copysign(abs(st) ** (2 / n), st)
        d.append(f"{'M' if i == 0 else 'L'}{x:.1f} {y:.1f}")
    return " ".join(d) + "Z"

SQ = squircle()

def gear(cx=256, cy=256, ro=112, ri=90, teeth=8):
    p = []
    for i in range(teeth * 4):
        a = 2 * math.pi * i / (teeth * 4) - math.pi / (teeth * 4)
        r = ro if (i % 4) in (1, 2) else ri
        p.append(f"{cx + r * math.cos(a):.1f},{cy + r * math.sin(a):.1f}")
    return f'<polygon points="{" ".join(p)}"/><circle cx="{cx}" cy="{cy}" r="36"/>'

STAR = "M256 128 C268 214 298 244 384 256 C298 268 268 298 256 384 C244 298 214 268 128 256 C214 244 244 214 256 128Z"

# glyphs drawn with white strokes (class g) — fill="url(#aur)" used for solid accents
G = {
 "files":   '<path d="M144 196a20 20 0 0 1 20-20h70l26 26h88a20 20 0 0 1 20 20v118a20 20 0 0 1-20 20H164a20 20 0 0 1-20-20Z"/><path d="M144 240h224"/>',
 "browser": '<circle cx="256" cy="256" r="112"/><path d="M300 212 278 278 212 300 234 234Z" fill="url(#aur)" stroke="none"/><circle cx="256" cy="256" r="10" fill="#fff" stroke="none"/>',
 "terminal":'<rect x="140" y="160" width="232" height="192" rx="26"/><path d="M190 222l42 36-42 36M256 300h66"/>',
 "settings": gear(),
 "music":   '<path d="M222 336V184l124-30v152"/><circle cx="194" cy="336" r="30"/><circle cx="318" cy="306" r="30"/>',
 "mail":    '<rect x="144" y="180" width="224" height="156" rx="22"/><path d="M152 196l104 78 104-78"/>',
 "calendar":'<rect x="148" y="164" width="216" height="196" rx="26"/><path d="M148 220h216M206 140v44M306 140v44"/><text x="256" y="328" text-anchor="middle" font-family="Inter,sans-serif" font-weight="700" font-size="92" fill="#fff" stroke="none">14</text>',
 "photos":  '<rect x="140" y="164" width="232" height="184" rx="26"/><path d="M152 330l70-78 52 52 32-30 58 56"/><circle cx="312" cy="216" r="20" fill="url(#aur)" stroke="none"/>',
 "notes":   '<rect x="164" y="140" width="184" height="232" rx="24"/><path d="M200 200h112M200 248h112M200 296h70"/>',
 "ai":      f'<path d="{STAR}" fill="url(#aur)" stroke="none"/><circle cx="256" cy="256" r="150" stroke-width="6" opacity=".55"/>',
 "apps":    "".join(f'<rect x="{150+i*80}" y="{150+j*80}" width="52" height="52" rx="16"/>' for i in range(3) for j in range(3)),
 "store":   '<path d="M160 208h192l-14 150H174Z"/><path d="M210 208v-22a46 46 0 0 1 92 0v22"/>',
 "code":    '<path d="M206 196l-62 60 62 60M306 196l62 60-62 60M276 170l-40 172"/>',
 "games":   '<path d="M190 196h132a62 62 0 0 1 60 76l-16 56a30 30 0 0 1-52 10l-26-30h-64l-26 30a30 30 0 0 1-52-10l-16-56a62 62 0 0 1 60-76Z"/><path d="M200 244v40M180 264h40"/><circle cx="310" cy="252" r="9" fill="#fff"/><circle cx="336" cy="278" r="9" fill="#fff"/>',
 "trash":   '<path d="M168 196h176M224 196v-24h64v24M186 196l14 164h112l14-164M236 240v84M276 240v84"/>',
 "video":   '<rect x="140" y="172" width="232" height="168" rx="28"/><path d="M236 216v80l66-40Z" fill="url(#aur)" stroke="none"/>',
 "monitor": '<rect x="140" y="160" width="232" height="192" rx="26"/><path d="M164 268h44l22-52 34 100 26-62 16 14h42"/>',
 "cube":    '<path d="M256 140l100 56v120l-100 56-100-56V196Z"/><path d="M156 196l100 56 100-56M256 252v120"/>',
 "chat":    '<path d="M148 222a62 62 0 0 1 62-62h92a62 62 0 0 1 62 62v20a62 62 0 0 1-62 62h-58l-58 46v-50a62 62 0 0 1-38-58Z"/><circle cx="214" cy="232" r="9" fill="#fff"/><circle cx="256" cy="232" r="9" fill="#fff"/><circle cx="298" cy="232" r="9" fill="#fff"/>',
 "maps":    '<path d="M150 190l70-30 72 30 70-30v170l-70 30-72-30-70 30Z"/><path d="M220 160v170M292 190v170"/>',
 "books":   '<path d="M150 170h76a30 30 0 0 1 30 30v160a22 22 0 0 0-22-22h-84Z"/><path d="M362 170h-76a30 30 0 0 0-30 30v160a22 22 0 0 1 22-22h84Z"/>',
 "folder":  '<path d="M144 200a22 22 0 0 1 22-22h62l26 26h92a22 22 0 0 1 22 22v108a22 22 0 0 1-22 22H166a22 22 0 0 1-22-22Z"/>',
 "ft-text":  '<path d="M170 140h120l52 52v180H170Z"/><path d="M290 140v52h52"/><path d="M206 236h100M206 276h100M206 316h64"/>',
 "ft-pdf":   '<path d="M170 140h120l52 52v180H170Z"/><path d="M290 140v52h52"/><text x="256" y="320" text-anchor="middle" font-family="Space Grotesk,Inter,sans-serif" font-weight="800" font-size="64" fill="#FF6B6B" stroke="none">PDF</text>',
 "ft-zip":   '<path d="M170 140h120l52 52v180H170Z"/><path d="M290 140v52h52"/><path d="M240 150v20M256 170v20M240 190v20M256 210v20M240 230v20"/><rect x="232" y="256" width="32" height="40" rx="8"/>',
 "ft-image": '<rect x="148" y="164" width="216" height="184" rx="26"/><path d="M160 330l64-70 50 48 30-28 56 50"/><circle cx="310" cy="214" r="18" fill="url(#aur)" stroke="none"/>',
 "ft-doc":   '<path d="M170 140h120l52 52v180H170Z"/><path d="M290 140v52h52"/><text x="256" y="320" text-anchor="middle" font-family="Space Grotesk,Inter,sans-serif" font-weight="800" font-size="62" fill="#7FB4FF" stroke="none">DOC</text>',
 "ft-design":'<path d="M170 140h120l52 52v180H170Z"/><path d="M290 140v52h52"/><circle cx="234" cy="282" r="34" fill="url(#aur)" stroke="none"/><path d="M262 300l40-70 40 70Z" fill="#FF9D6E" stroke="none"/>',
 "ft-video": '<path d="M170 140h120l52 52v180H170Z"/><path d="M290 140v52h52"/><path d="M232 238v84l66-42Z" fill="url(#aur)" stroke="none"/>',
 "ft-audio": '<path d="M170 140h120l52 52v180H170Z"/><path d="M290 140v52h52"/><path d="M240 320v-90l64-16v80"/><circle cx="222" cy="320" r="18"/><circle cx="286" cy="294" r="18"/>',
 "ft-code":  '<path d="M170 140h120l52 52v180H170Z"/><path d="M290 140v52h52"/><path d="M226 246l-30 34 30 34M286 246l30 34-30 34"/>',
 "ft-app":   '<rect x="160" y="160" width="192" height="192" rx="44"/><path d="M256 208v96M208 256h96"/>',
 "control": '<path d="M160 196h192M160 256h192M160 316h192"/><circle cx="210" cy="196" r="20" fill="url(#aur)"/><circle cx="306" cy="256" r="20" fill="url(#aur)"/><circle cx="240" cy="316" r="20" fill="url(#aur)"/>',
}

# accent per icon: glow tint (keeps unity, adds identity)
ACC = {"files":"#38bdf8","browser":"#22d3ee","terminal":"#a3e635","settings":"#a78bfa","music":"#f472b6",
       "mail":"#60a5fa","calendar":"#fb7185","photos":"#fbbf24","notes":"#facc15","ai":"#c084fc","apps":"#818cf8",
       "store":"#2dd4bf","code":"#3b82f6","games":"#a78bfa","trash":"#94a3b8","video":"#f43f5e","monitor":"#34d399",
       "cube":"#fb923c","maps":"#6ce675","ft-text":"#e5e7eb","ft-pdf":"#ff6b6b","ft-zip":"#ffd166","ft-image":"#8adae3","ft-doc":"#7fb4ff","ft-design":"#ff9d6e","ft-video":"#f472b6","ft-audio":"#b3a6ff","ft-code":"#6ce675","ft-app":"#b3a6ff","books":"#ff9d6e","folder":"#8adae3","chat":"#4ade80","control":"#22d3ee"}

def icon_svg(name):
    a = ACC[name]
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
<defs>
 <linearGradient id="body" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2F2F4A"/><stop offset="1" stop-color="#0B0B17"/></linearGradient>
 <radialGradient id="tint" cx=".5" cy="1" r=".75"><stop offset="0" stop-color="{a}" stop-opacity=".38"/><stop offset="1" stop-color="{a}" stop-opacity="0"/></radialGradient>
 <radialGradient id="shine" cx=".3" cy="0" r=".8"><stop offset="0" stop-color="#fff" stop-opacity=".22"/><stop offset=".6" stop-color="#fff" stop-opacity="0"/></radialGradient>
 <linearGradient id="rim" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#8ADAE3"/><stop offset=".5" stop-color="#B3A6FF"/><stop offset="1" stop-color="#FF9D6E"/></linearGradient>
 <linearGradient id="aur" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#67e8f9"/><stop offset=".55" stop-color="#c4b5fd"/><stop offset="1" stop-color="#f9a8d4"/></linearGradient>
 <clipPath id="clip"><path d="{SQ}"/></clipPath>
 <filter id="glow" x="-30%" y="-30%" width="160%" height="160%">
  <feGaussianBlur in="SourceAlpha" stdDeviation="9" result="b"/><feFlood flood-color="{a}" flood-opacity=".95"/>
  <feComposite in2="b" operator="in" result="g"/><feMerge><feMergeNode in="g"/><feMergeNode in="SourceGraphic"/></feMerge>
 </filter>
</defs>
<path d="{SQ}" fill="url(#body)"/>
<path d="{SQ}" fill="url(#tint)"/>
<path d="{SQ}" fill="url(#shine)"/>
<path d="{SQ}" fill="none" stroke="url(#rim)" stroke-width="12" opacity=".85" clip-path="url(#clip)"/>
<g filter="url(#glow)" fill="none" stroke="#fff" stroke-width="18" stroke-linecap="round" stroke-linejoin="round">{G[name]}</g>
</svg>'''

ALIASES = {
 "files": ["system-file-manager","org.gnome.Nautilus","thunar","org.xfce.thunar","nemo","pcmanfm"],
 "browser": ["web-browser","firefox","org.mozilla.firefox","firefox-esr","chromium","google-chrome","brave-browser","microsoft-edge","zen-browser"],
 "terminal": ["utilities-terminal","kitty","foot","org.gnome.Terminal","org.gnome.Console","Alacritty","org.wezfurlong.wezterm","xfce4-terminal"],
 "settings": ["aurora-settings","preferences-system","org.gnome.Settings","gnome-control-center","systemsettings","nwg-look","xfce4-settings-manager"],
 "music": ["multimedia-audio-player","spotify","spotify-client","com.spotify.Client","rhythmbox","org.gnome.Rhythmbox3","org.gnome.Music","elisa"],
 "mail": ["mail-client","thunderbird","org.mozilla.Thunderbird","evolution","org.gnome.Geary"],
 "calendar": ["office-calendar","org.gnome.Calendar","x-office-calendar"],
 "photos": ["image-viewer","org.gnome.Loupe","eog","org.gnome.eog","shotwell","gthumb","imv"],
 "notes": ["accessories-text-editor","org.gnome.TextEditor","gedit","mousepad","org.xfce.mousepad","obsidian","kate"],
 "ai": ["aurora-ai"],
 "apps": ["aurora-apps","view-app-grid","rofi"],
 "store": ["system-software-install","org.gnome.Software","software-store","pamac-manager","org.kde.discover"],
 "code": ["code","visual-studio-code","com.visualstudio.code","vscodium","codium","jetbrains-toolbox"],
 "games": ["steam","applications-games","lutris","heroic","com.valvesoftware.Steam"],
 "trash": ["user-trash","user-trash-full"],
 "video": ["multimedia-video-player","vlc","mpv","org.gnome.Totem","totem","celluloid"],
 "monitor": ["utilities-system-monitor","org.gnome.SystemMonitor","btop","htop","gnome-system-monitor"],
 "cube": ["blender","org.blender.Blender"],
 "chat": ["internet-chat","discord","com.discordapp.Discord","telegram","org.telegram.desktop","signal-desktop","whatsapp"],
 "control": ["aurora-control","preferences-desktop"],
 "maps": ["org.gnome.Maps","gnome-maps"],
 "books": ["org.gnome.Evince","evince","foliate","com.github.johnfactotum.Foliate","org.gnome.Papers"],
 "folder": ["folder","folder-blue","inode-directory"],
}

# ---- symbolic UI icons for the widgets (24px, stroke) ----
SYM = {
 "wifi": '<path d="M2 9a15 15 0 0 1 20 0M5 12.5a10 10 0 0 1 14 0M8.5 16a5 5 0 0 1 7 0"/><circle cx="12" cy="19.5" r="1.2" fill="currentColor"/>',
 "bluetooth": '<path d="M7 7l10 10-5 4V3l5 4L7 17"/>',
 "moon": '<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5Z"/>',
 "plane": '<path d="M10.5 20.5 12 15l6 3 2-1-6-6 1-6.5a1.5 1.5 0 0 0-3 0L11 11 5 17l2 1 4-2"/>',
 "volume": '<path d="M4 9.5h4l5-4v13l-5-4H4Z"/><path d="M16.5 8.5a5 5 0 0 1 0 7M19 6a8.5 8.5 0 0 1 0 12"/>',
 "sun": '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
 "play": '<path d="M8 5v14l11-7Z" fill="currentColor"/>',
 "pause": '<path d="M8 5v14M16 5v14" stroke-width="3"/>',
 "next": '<path d="M5 6v12l9-6Z" fill="currentColor"/><path d="M18 6v12"/>',
 "prev": '<path d="M19 6v12l-9-6Z" fill="currentColor"/><path d="M6 6v12"/>',
 "heart": '<path d="M12 20s-7.5-4.6-7.5-10A4.3 4.3 0 0 1 12 7.6 4.3 4.3 0 0 1 19.5 10C19.5 15.4 12 20 12 20Z"/>',
 "search": '<circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/>',
 "send": '<path d="M4 12 20 4l-5 16-3.5-6.5Z"/><path d="M11.5 13.5 20 4"/>',
 "sparkle": '<path d="M12 3c.8 5 3.9 8.2 9 9-5.1.8-8.2 4-9 9-.8-5-3.9-8.2-9-9 5.1-.8 8.2-4 9-9Z" fill="currentColor"/>',
 "grid": '<rect x="4" y="4" width="6" height="6" rx="2"/><rect x="14" y="4" width="6" height="6" rx="2"/><rect x="4" y="14" width="6" height="6" rx="2"/><rect x="14" y="14" width="6" height="6" rx="2"/>',
 "sliders": '<path d="M4 7h16M4 12h16M4 17h16"/><circle cx="9" cy="7" r="2" fill="currentColor"/><circle cx="15" cy="12" r="2" fill="currentColor"/><circle cx="8" cy="17" r="2" fill="currentColor"/>',
 "power": '<path d="M12 3v8"/><path d="M6.5 6.5a8 8 0 1 0 11 0"/>',
 "calendar": '<rect x="3.5" y="5" width="17" height="15.5" rx="3"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
 "doc": '<path d="M6 3h8l4 4v14H6Z"/><path d="M9 12h6M9 16h6"/>',
 "wand": '<path d="m4 20 11-11M14 4v3M19 9h-3M17.5 5.5l-2 2"/>',
 "home": '<path d="M4 11 12 4l8 7"/><path d="M6 9.5V20h12V9.5"/><path d="M10 20v-5h4v5"/>',
 "desktop": '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>',
 "download": '<path d="M12 4v11M7 10.5 12 15.5l5-5"/><path d="M5 20h14"/>',
 "folder": '<path d="M3.5 7a2 2 0 0 1 2-2h4l2 2h7a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2Z"/>',
 "drive": '<rect x="3" y="13" width="18" height="7" rx="2"/><path d="M5 13 7.5 5h9L19 13"/><circle cx="17" cy="16.5" r="1" fill="currentColor"/>',
 "network": '<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.5 2.6 2.5 14.4 0 17M12 3.5c-2.5 2.6-2.5 14.4 0 17"/>',
 "gear": '<circle cx="12" cy="12" r="3"/><path d="M12 2.8v2.4M12 18.8v2.4M2.8 12h2.4M18.8 12h2.4M5.5 5.5l1.7 1.7M16.8 16.8l1.7 1.7M5.5 18.5l1.7-1.7M16.8 7.2l1.7-1.7"/>',
 "focus": '<path d="M15.5 4.5A8 8 0 1 0 19.5 15 6.5 6.5 0 0 1 15.5 4.5Z"/><circle cx="17.5" cy="6.5" r="1.4" fill="currentColor"/>',
 "darkmode": '<circle cx="12" cy="12" r="8.5"/><path d="M12 3.5a8.5 8.5 0 0 1 0 17Z" fill="currentColor"/>',
 "mirror": '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8.5 20h7M12 16v4"/><path d="M9 10.5h6M13 8.5l2 2-2 2"/>',
 "keyboard": '<rect x="2.5" y="6" width="19" height="12" rx="2.5"/><path d="M6 10h.01M9 10h.01M12 10h.01M15 10h.01M18 10h.01M7.5 14h9"/>',
 "battery": '<rect x="2.5" y="7" width="17" height="10" rx="2.5"/><path d="M21.5 10.5v3"/><rect x="5" y="9.5" width="9" height="5" rx="1" fill="currentColor"/>',
 "bell": '<path d="M6 16V11a6 6 0 0 1 12 0v5l1.5 2h-15Z"/><path d="M10 20.5a2 2 0 0 0 4 0"/>',
 "record": '<circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="4" fill="currentColor"/>',
 "check": '<path d="m6 12.5 4 4 8-9"/>',
 "note": '<path d="M5 4h14v11l-5 5H5Z"/><path d="M14 20v-5h5M8.5 9h7M8.5 12.5h4"/>',
 "lock": '<rect x="5" y="10.5" width="14" height="10" rx="2.5"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/>',
 "logout": '<path d="M14 4H6v16h8M10 12h10M17 9l3 3-3 3"/>',
 "restart": '<path d="M19.5 12A7.5 7.5 0 1 1 17 6.4"/><path d="M19.5 3.5v4h-4"/>',
 "chevron": '<path d="m9 6 6 6-6 6"/>',
 "close": '<path d="M6.5 6.5l11 11M17.5 6.5l-11 11"/>',
}

def sym_svg(body, color="#ffffff"):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="48" height="48" color="{color}" '
            f'fill="none" stroke="{color}" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">{body}</svg>')

def main():
    apps = os.path.join(OUT, "scalable", "apps"); os.makedirs(apps, exist_ok=True)
    places = os.path.join(OUT, "scalable", "places"); os.makedirs(places, exist_ok=True)
    for k in G:
        svg = icon_svg(k)
        open(os.path.join(apps, f"aurora-{k}.svg"), "w").write(svg)
        for a in ALIASES.get(k, []):
            open(os.path.join(apps, f"{a}.svg"), "w").write(svg)
    for t in ("user-trash", "user-trash-full"):
        open(os.path.join(places, f"{t}.svg"), "w").write(icon_svg("trash"))
    open(os.path.join(OUT, "index.theme"), "w").write(
        "[Icon Theme]\nName=Aurora-Squircle\nComment=Unified squircle icons with aurora neon rim\n"
        "Inherits=Papirus-Dark,Adwaita,hicolor\nDirectories=scalable/apps,scalable/places\n\n"
        "[scalable/apps]\nSize=512\nMinSize=16\nMaxSize=1024\nType=Scalable\nContext=Applications\n\n"
        "[scalable/places]\nSize=512\nMinSize=16\nMaxSize=1024\nType=Scalable\nContext=Places\n")
    symd = sys.argv[2] if len(sys.argv) > 2 else "eww/icons"
    os.makedirs(symd, exist_ok=True)
    for k, b in SYM.items():
        open(os.path.join(symd, f"{k}.svg"), "w").write(sym_svg(b))
        open(os.path.join(symd, f"{k}-dark.svg"), "w").write(sym_svg(b, "#1b1440"))
    for k in G:  # dock copies
        open(os.path.join(symd, f"app-{k}.svg"), "w").write(icon_svg(k))
    print("icons:", len(os.listdir(apps)), "symbolic:", len(SYM))

if __name__ == "__main__":
    main()
