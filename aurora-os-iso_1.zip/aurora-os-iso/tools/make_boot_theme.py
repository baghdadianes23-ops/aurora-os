#!/usr/bin/env python3
"""Aurora boot visuals: GRUB theme (glass menu) + Plymouth splash + live-USB splash."""
import math, os, sys
from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageEnhance
WALL, ROOT = sys.argv[1], sys.argv[2]
G = f"{ROOT}/boot/grub/themes/aurora"; P = f"{ROOT}/usr/share/plymouth/themes/aurora"
os.makedirs(f"{G}/icons", exist_ok=True); os.makedirs(P, exist_ok=True)
FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FONT_L = "/usr/share/fonts/truetype/dejavu/DejaVuSans-ExtraLight.ttf"
if not os.path.exists(FONT_L): FONT_L = FONT

def star(size, color=(255, 255, 255, 255), glow=True):
    im = Image.new("RGBA", (size, size), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    c, R = size / 2, size * 0.46
    pts = []
    for i in range(160):
        t = 2 * math.pi * i / 160; ct, st = math.cos(t), math.sin(t)
        pts.append((c + R * math.copysign(abs(ct) ** 3, ct), c + R * math.copysign(abs(st) ** 3, st)))
    d.polygon(pts, fill=color)
    if glow:
        g = im.filter(ImageFilter.GaussianBlur(size * 0.06))
        base = Image.new("RGBA", im.size, (0, 0, 0, 0))
        tint = Image.new("RGBA", im.size, (179, 166, 255, 0)); tint.putalpha(g.getchannel("A"))
        base = Image.alpha_composite(base, tint); base = Image.alpha_composite(base, tint)
        im = Image.alpha_composite(base, im)
    return im

def background(w, h, dim=0.45, blur=10, title=True):
    bg = Image.open(WALL).convert("RGB")
    r = max(w / bg.width, h / bg.height); bg = bg.resize((int(bg.width * r) + 1, int(bg.height * r) + 1), Image.LANCZOS)
    x, y = (bg.width - w) // 2, (bg.height - h) // 2; bg = bg.crop((x, y, x + w, y + h))
    bg = bg.filter(ImageFilter.GaussianBlur(blur)); bg = ImageEnhance.Brightness(bg).enhance(dim)
    bg = bg.convert("RGBA")
    if title:
        s = star(int(h * 0.08)); bg.alpha_composite(s, ((w - s.width) // 2, int(h * 0.09)))
        d = ImageDraw.Draw(bg); f = ImageFont.truetype(FONT_L, int(h * 0.05))
        d.text((w // 2, int(h * 0.23)), "A U R O R A   O S", font=f, fill=(255, 255, 255, 240), anchor="mm")
        f2 = ImageFont.truetype(FONT, int(h * 0.018))
        d.text((w // 2, int(h * 0.28)), "Dream  ·  Create  ·  Beyond", font=f2, fill=(201, 191, 255, 220), anchor="mm")
    return bg

def nine_slice(prefix, fill, border, r=16):
    """GRUB styled box: prefix_{nw,n,ne,w,c,e,sw,s,se}.png with 16 px rounded glass corners."""
    S = r * 3
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle([0, 0, S - 1, S - 1], r, fill=fill, outline=border, width=1)
    parts = {"nw": (0, 0), "n": (1, 0), "ne": (2, 0), "w": (0, 1), "c": (1, 1), "e": (2, 1), "sw": (0, 2), "s": (1, 2), "se": (2, 2)}
    for k, (cx, cy) in parts.items():
        im.crop((cx * r, cy * r, cx * r + r, cy * r + r)).save(f"{G}/{prefix}_{k}.png")

# ---------------- GRUB
background(1920, 1080).convert("RGB").save(f"{G}/background.png", optimize=True)
nine_slice("menu", (20, 21, 38, 150), (255, 255, 255, 50))
nine_slice("select", (179, 166, 255, 95), (201, 191, 255, 170))
nine_slice("terminal_box", (11, 11, 23, 220), (255, 255, 255, 40))
def icon(name, draw):
    im = Image.new("RGBA", (64, 64), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rounded_rectangle([2, 2, 61, 61], 18, fill=(47, 47, 74, 230), outline=(179, 166, 255, 200), width=2)
    draw(im, d); im.save(f"{G}/icons/{name}.png")
def aurora_icon(im, d): s = star(40, glow=False); im.alpha_composite(s, (12, 12))
def window_icon(im, d):  # generic "other OS" window glyph
    d.rounded_rectangle([14, 18, 50, 46], 5, outline=(255, 255, 255, 235), width=3); d.line([14, 26, 50, 26], fill=(255, 255, 255, 235), width=3)
def tux_icon(im, d):     # generic Linux: terminal prompt
    d.line([17, 22, 29, 32, 17, 42], fill=(255, 255, 255, 235), width=4, joint="curve"); d.line([33, 44, 47, 44], fill=(255, 255, 255, 235), width=4)
def gear_icon(im, d):
    d.ellipse([20, 20, 44, 44], outline=(255, 255, 255, 235), width=4); d.ellipse([28, 28, 36, 36], fill=(255, 255, 255, 235))
def disk_icon(im, d):
    d.rounded_rectangle([14, 20, 50, 44], 6, outline=(255, 255, 255, 235), width=3); d.ellipse([40, 29, 46, 35], fill=(255, 255, 255, 235))
for n, f in [("aurora", aurora_icon), ("debian", aurora_icon), ("gnu-linux", aurora_icon), ("windows", window_icon),
             ("linux", tux_icon), ("ubuntu", tux_icon), ("fedora", tux_icon), ("arch", tux_icon), ("macosx", window_icon),
             ("recovery", gear_icon), ("efi", gear_icon), ("os", disk_icon)]:
    icon(n, f)

# ---------------- Plymouth
background(1920, 1080, dim=0.30, blur=18, title=False).convert("RGB").save(f"{P}/background.png", optimize=True)
star(220).save(f"{P}/logo.png")
im = Image.new("RGBA", (900, 120), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
d.text((450, 50), "A U R O R A   O S", font=ImageFont.truetype(FONT_L, 64), fill=(255, 255, 255, 245), anchor="mm")
d.text((450, 104), "Dream  ·  Create  ·  Beyond", font=ImageFont.truetype(FONT, 22), fill=(201, 191, 255, 230), anchor="mm")
im.save(f"{P}/title.png")
bar = Image.new("RGBA", (360, 6), (0, 0, 0, 0)); ImageDraw.Draw(bar).rounded_rectangle([0, 0, 359, 5], 3, fill=(255, 255, 255, 45)); bar.save(f"{P}/bar-bg.png")
fill = Image.new("RGBA", (360, 6), (0, 0, 0, 0)); fd = ImageDraw.Draw(fill)
for x in range(360):
    t = x / 359; c = (int(138 + (179 - 138) * t), int(218 + (166 - 218) * t), int(227 + (255 - 227) * t), 255); fd.line([x, 0, x, 5], fill=c)
m = Image.new("L", (360, 6), 0); ImageDraw.Draw(m).rounded_rectangle([0, 0, 359, 5], 3, fill=255); fill.putalpha(m); fill.save(f"{P}/bar.png")
box = Image.new("RGBA", (440, 120), (0, 0, 0, 0)); ImageDraw.Draw(box).rounded_rectangle([0, 0, 439, 119], 16, fill=(20, 21, 38, 200), outline=(255, 255, 255, 60)); box.save(f"{P}/box.png")
dot = Image.new("RGBA", (14, 14), (0, 0, 0, 0)); ImageDraw.Draw(dot).ellipse([0, 0, 13, 13], fill=(244, 242, 255, 255)); dot.save(f"{P}/bullet.png")
# ---------------- live USB menu splash
background(1920, 1080, dim=0.42, blur=8).convert("RGB").save(f"{ROOT}/../bootloaders-splash.png", optimize=True)
print("boot visuals ok")
