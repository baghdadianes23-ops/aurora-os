#!/usr/bin/env python3
"""Mini desktop previews for Aurora Settings → Appearance (Light / Dark / Aurora)."""
import sys
from PIL import Image, ImageDraw, ImageFilter, ImageEnhance
wall, out = sys.argv[1], sys.argv[2]
W, H = 300, 188
base = Image.open(wall).convert("RGB").resize((W, H), Image.LANCZOS)
def glass(img, box, fill, r=10):
    x0, y0, x1, y1 = box
    region = img.crop(box).filter(ImageFilter.GaussianBlur(6))
    tint = Image.new("RGB", region.size, fill[:3])
    region = Image.blend(region, tint, fill[3])
    m = Image.new("L", region.size, 0); ImageDraw.Draw(m).rounded_rectangle([0, 0, x1-x0-1, y1-y0-1], r, fill=255)
    img.paste(region, (x0, y0), m)
    ImageDraw.Draw(img, "RGBA").rounded_rectangle(box, r, outline=(255, 255, 255, 60))
for name, bg, fill, bar, accent in [
        ("light",  ImageEnhance.Brightness(base).enhance(1.15), (235, 233, 250, .62), (245, 245, 252, 200), (179, 166, 255)),
        ("dark",   ImageEnhance.Color(ImageEnhance.Brightness(base).enhance(0.55)).enhance(0.5), (11, 11, 23, .78), (11, 11, 23, 220), (138, 218, 227)),
        ("aurora", base, (26, 27, 46, .55), (11, 11, 23, 150), (179, 166, 255))]:
    img = bg.copy()
    d = ImageDraw.Draw(img, "RGBA")
    d.rectangle([0, 0, W, 10], fill=bar)
    glass(img, (12, 20, 92, 110), fill)                 # sidebar/weather
    glass(img, (208, 20, 288, 70), fill)                # music
    glass(img, (208, 78, 288, 150), fill)               # system monitor
    glass(img, (100, 60, 200, 140), fill, 12)           # window
    d = ImageDraw.Draw(img, "RGBA")
    for i, c in enumerate([(255, 107, 107), (255, 209, 102), (108, 230, 117)]):
        d.ellipse([106 + i * 8, 65, 111 + i * 8, 70], fill=c)
    for i in range(3):
        d.ellipse([222, 92 + i * 18, 234, 104 + i * 18], outline=accent + (255,), width=2)
    glass(img, (80, 162, 220, 182), (26, 27, 46, .5), 8)   # dock
    for i in range(8):
        d.rounded_rectangle([88 + i * 16, 166, 99 + i * 16, 177], 3, fill=accent + (220,) if i == 4 else (255, 255, 255, 170))
    img.save(f"{out}/theme-{name}.png", optimize=True)
print("previews ok")
