#!/usr/bin/env python3
"""Bake the frosted-glass login card into the background (identical on every GPU/VM)."""
import sys
from PIL import Image, ImageDraw, ImageFilter
src, out = sys.argv[1], sys.argv[2]
W, H = 1920, 1080
bg = Image.open(src).convert("RGB").resize((W, H), Image.LANCZOS)
cw, ch, r = 440, 520, 16
x0, y0 = (W - cw) // 2, (H - ch) // 2 + 40
blur = bg.filter(ImageFilter.GaussianBlur(28))
tint = Image.new("RGB", (W, H), (20, 15, 48))
glass = Image.blend(blur, tint, 0.45)
mask = Image.new("L", (W, H), 0)
ImageDraw.Draw(mask).rounded_rectangle([x0, y0, x0 + cw, y0 + ch], r, fill=255)
# soft shadow
sh = Image.new("L", (W, H), 0)
ImageDraw.Draw(sh).rounded_rectangle([x0, y0 + 14, x0 + cw, y0 + ch + 14], r, fill=150)
sh = sh.filter(ImageFilter.GaussianBlur(26))
bg = Image.composite(Image.new("RGB", (W, H), (6, 4, 18)), bg, sh)
bg = Image.composite(glass, bg, mask)
d = ImageDraw.Draw(bg, "RGBA")
d.rounded_rectangle([x0, y0, x0 + cw, y0 + ch], r, outline=(255, 255, 255, 48), width=1)
# top highlight line
d.line([x0 + r, y0 + 1, x0 + cw - r, y0 + 1], fill=(255, 255, 255, 70), width=1)
bg.save(out, optimize=True)
print("card:", x0, y0, cw, ch)
