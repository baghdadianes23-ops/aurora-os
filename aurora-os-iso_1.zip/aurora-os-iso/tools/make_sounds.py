#!/usr/bin/env python3
"""Aurora sound theme — original, calm 'glass & light' tones (freedesktop sound theme spec)."""
import numpy as np, os, subprocess, sys, wave
SR = 48000
OUT = sys.argv[1] if len(sys.argv) > 1 else "aurora"

def tone(f, dur, amp=0.3, attack=0.01, decay=None, partials=(1, 2.01, 3.0), weights=(1, .35, .12)):
    t = np.linspace(0, dur, int(SR * dur), False)
    s = sum(w * np.sin(2 * np.pi * f * p * t) for p, w in zip(partials, weights))
    env = np.minimum(1, t / attack) * np.exp(-t / (decay or dur / 3.5))
    return amp * s * env

def at(buf, sig, start):
    i = int(start * SR); end = i + len(sig)
    if end > len(buf): buf = np.pad(buf, (0, end - len(buf)))
    buf[i:end] += sig; return buf

def reverb(x, mix=0.32):
    out = x.copy()
    for d, g in ((0.031, .5), (0.047, .42), (0.071, .35), (0.113, .28), (0.161, .2), (0.233, .14)):
        k = int(d * SR); y = np.zeros(len(x) + k); y[k:] = x * g
        out = np.pad(out, (0, len(y) - len(out))) + y * mix
    return out

def stereo(x, width=0.004):
    k = int(width * SR); r = np.pad(x, (k, 0))[:len(x)]
    return np.stack([x, r * 0.92], axis=1)

def save(name, x):
    x = reverb(x); x = np.concatenate([x, np.zeros(int(0.05 * SR))])
    x = x / max(1e-9, np.max(np.abs(x))) * 0.7
    st = (stereo(x) * 32767).astype(np.int16)
    os.makedirs(f"{OUT}/stereo", exist_ok=True)
    wav = f"{OUT}/stereo/{name}.wav"
    with wave.open(wav, "wb") as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(st.tobytes())
    subprocess.run(["ffmpeg", "-loglevel", "error", "-y", "-i", wav, "-c:a", "libvorbis", "-q:a", "5",
                    f"{OUT}/stereo/{name}.oga"], check=True)
    os.remove(wav)

N = lambda m: 440 * 2 ** ((m - 69) / 12)   # midi -> Hz

# startup / login: rising major-9 arpeggio, airy
b = np.zeros(1)
for i, m in enumerate([57, 64, 69, 71, 76, 81]):
    b = at(b, tone(N(m), 2.6, .22, attack=.04, decay=1.1), i * 0.12)
b = at(b, tone(N(45), 3.0, .18, attack=.3, decay=1.6, partials=(1, 2), weights=(1, .2)), 0)
save("system-ready", b); save("desktop-login", b[: int(SR * 2.2)])
# logout: gentle descending
b = np.zeros(1)
for i, m in enumerate([81, 76, 71, 64]):
    b = at(b, tone(N(m), 1.4, .22, decay=.6), i * 0.11)
save("desktop-logout", b)
# notification: two-tone glass ping
b = at(np.zeros(1), tone(N(88), .9, .3, decay=.25, partials=(1, 2.76, 5.4), weights=(1, .3, .1)), 0)
b = at(b, tone(N(93), 1.0, .26, decay=.3, partials=(1, 2.76, 5.4), weights=(1, .3, .1)), .09)
save("message-new-instant", b); save("message", b)
# complete / success
b = np.zeros(1)
for i, m in enumerate([76, 83, 88]): b = at(b, tone(N(m), .8, .25, decay=.25), i * .07)
save("complete", b)
# error: soft low double knock (not harsh)
b = at(np.zeros(1), tone(N(50), .45, .45, decay=.09, partials=(1, 1.5, 2.2), weights=(1, .4, .1)), 0)
b = at(b, tone(N(45), .5, .45, decay=.11, partials=(1, 1.5, 2.2), weights=(1, .4, .1)), .13)
save("dialog-error", b); save("bell", b[: int(SR * .3)])
# warning
b = at(np.zeros(1), tone(N(69), .7, .3, decay=.18), 0); b = at(b, tone(N(66), .7, .3, decay=.2), .16)
save("dialog-warning", b); save("dialog-information", tone(N(81), .8, .3, decay=.22))
# small UI sounds
save("audio-volume-change", tone(N(84), .12, .35, decay=.03, partials=(1, 3), weights=(1, .2)))
b = at(np.zeros(1), tone(N(96), .25, .3, decay=.05), 0); b = at(b, tone(N(91), .3, .25, decay=.06), .05)
save("screen-capture", b)
b = at(np.zeros(1), tone(N(72), .5, .3, decay=.12), 0); b = at(b, tone(N(79), .6, .3, decay=.15), .08)
save("device-added", b); save("power-plug", b)
b = at(np.zeros(1), tone(N(79), .5, .3, decay=.12), 0); b = at(b, tone(N(72), .6, .3, decay=.15), .08)
save("device-removed", b); save("power-unplug", b)
save("trash-empty", tone(N(60), .5, .3, decay=.12, partials=(1, 1.33, 2.1), weights=(1, .6, .3)))

open(f"{OUT}/index.theme", "w").write(
    "[Sound Theme]\nName=Aurora\nComment=Calm glass-and-light sounds for Aurora OS\n"
    "Inherits=freedesktop\nDirectories=stereo\n\n[stereo]\nOutputProfile=stereo\n")
print("sounds:", sorted(f[:-4] for f in os.listdir(f"{OUT}/stereo")))
