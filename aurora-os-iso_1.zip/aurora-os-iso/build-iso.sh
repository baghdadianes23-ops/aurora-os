#!/usr/bin/env bash
# ============================================================
#   AURORA OS — ISO builder
#   Run on Debian 13 (or 12) as root:      sudo ./build-iso.sh
#   Result: aurora-os-YYYY-MM-DD-amd64.iso  (live + installer, burn it with Rufus)
#   Needs: internet, ~25 GB free disk, 40–90 minutes the first time.
# ============================================================
set -eo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
BUILD="${BUILD_DIR:-$HERE/build}"
LOG="$HERE/build.log"
DATE=$(date +%F)
P='\033[1;35m'; R='\033[1;31m'; N='\033[0m'
say(){ echo -e "${P}✦ $*${N}"; }
die(){ echo -e "${R}✗ $*${N}"; exit 1; }

[ "$(id -u)" -eq 0 ] || die "Run as root:  sudo ./build-iso.sh"
. /etc/os-release
[ "$ID" = debian ] || die "Please build on Debian (12 or 13). Detected: $PRETTY_NAME"
FREE=$(df -BG --output=avail "$HERE" | tail -1 | tr -dc 0-9)
[ "${FREE:-0}" -ge 20 ] || die "Not enough disk space: ${FREE}G free, 20G+ needed."

say "1/4  Installing build tools…"
apt-get update -qq
if [ "${VERSION_ID%%.*}" -lt 13 ]; then
  # Debian 12 host: live-build/debootstrap must come from trixie to build a trixie image
  echo "deb http://deb.debian.org/debian trixie main" > /etc/apt/sources.list.d/aurora-trixie-tmp.list
  apt-get update -qq
  apt-get install -y -t trixie live-build debootstrap
  rm /etc/apt/sources.list.d/aurora-trixie-tmp.list; apt-get update -qq
else
  apt-get install -y live-build debootstrap
fi
apt-get install -y xorriso squashfs-tools mtools dosfstools git ca-certificates

say "2/4  Preparing build folder: $BUILD"
if [ -d "$BUILD" ]; then ( cd "$BUILD" && lb clean --purge >/dev/null 2>&1 || true ); fi
rm -rf "$BUILD"; mkdir -p "$BUILD"
cp -a "$HERE/config" "$BUILD/config"
cd "$BUILD"
# repair files that passed through Windows: CRLF line endings + lost execute bits
find config -type f \( -name "*.sh" -o -name "*.py" -o -name "*.conf" -o -name "*.yuck" -o -name "*.scss" \
     -o -name "*.list.*" -o -name "*.pref.*" -o -name "*.hook.chroot" -o -name "*.desktop" -o -name "*.json" \
     -o -name "*.ini" -o -name "*.qml" -o -name "*.service" -o -name "*.timer" -o -path "*/bin/*" -o -path "*/sbin/*" \
     -o -path "*/lib/live/config/*" -o -path "*/sudoers.d/*" \) -exec sed -i 's/\r$//' {} +
find config -type f \( -path "*/hooks/*" -o -path "*/bin/*" -o -path "*/sbin/*" -o -path "*/eww/scripts/*" \
     -o -path "*/lib/live/config/*" \) -exec chmod 755 {} +

lb config \
  --mode debian \
  --distribution trixie \
  --architectures amd64 \
  --archive-areas "main contrib non-free non-free-firmware" \
  --updates true --security true \
  --binary-images iso-hybrid \
  --bootloaders "grub-efi,syslinux" \
  --debian-installer none \
  --firmware-binary true --firmware-chroot true \
  --linux-packages "linux-image linux-headers" \
  --iso-application "Aurora OS" \
  --iso-publisher "Aurora OS" \
  --iso-volume "AURORA_OS" \
  --memtest none \
  --bootappend-live "boot=live components quiet splash username=aurora hostname=aurora-os user-fullname=Aurora locales=en_US.UTF-8 keyboard-layouts=us,ar keyboard-options=grp:alt_shift_toggle" \
  --cache true \
  2>&1 | tee "$LOG"

# Aurora splash for the live USB boot menu (UEFI GRUB): copy live-build's own
# templates unchanged and only swap the background picture
LBB=/usr/share/live/build/bootloaders/grub-pc
if [ -d "$LBB" ] && [ -f "$HERE/tools/live-splash.png" ]; then
  mkdir -p config/bootloaders && cp -a "$LBB" config/bootloaders/
  find config/bootloaders/grub-pc -name 'splash.png' -exec cp "$HERE/tools/live-splash.png" {} \;
  [ -f config/bootloaders/grub-pc/splash.png ] || cp "$HERE/tools/live-splash.png" config/bootloaders/grub-pc/splash.png
fi

say "3/4  Building the image (this is the long part)…  log: $LOG"
lb build 2>&1 | tee -a "$LOG"

say "4/4  Finishing…"
ISO=$(ls -t "$BUILD"/*.iso 2>/dev/null | head -1)
[ -n "$ISO" ] || die "Build failed — see the last lines of $LOG"
OUT="$HERE/aurora-os-$DATE-amd64.iso"
mv "$ISO" "$OUT"
( cd "$HERE" && sha256sum "$(basename "$OUT")" > "$(basename "$OUT").sha256" )
[ -n "${SUDO_USER:-}" ] && chown "$SUDO_USER": "$OUT" "$OUT.sha256" "$LOG"
say "Done ✨  $OUT  ($(du -h "$OUT" | cut -f1))"
echo "   Test it:  qemu-system-x86_64 -enable-kvm -m 6G -smp 4 -vga virtio -display gtk,gl=on -cdrom $(basename "$OUT")"
echo "   Burn it:  Rufus → select the ISO → when asked, choose 'DD Image' mode."
