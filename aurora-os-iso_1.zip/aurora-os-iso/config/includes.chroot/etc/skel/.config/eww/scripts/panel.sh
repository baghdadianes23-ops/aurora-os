#!/usr/bin/env bash
# Toggle an overlay panel with its slide animation: control | assistant | open-assistant
w=$1
if [ "$w" = open-assistant ]; then
  eww active-windows | grep -q '^assistant' && exit 0
  w=assistant
fi
if eww active-windows | grep -q "^$w"; then
  eww update ${w}_open=false; sleep 0.33; eww close "$w"
else
  if [ "$w" = control ]; then
    eww update cc="$(~/.config/eww/scripts/control.sh status)"
    eww active-windows | grep -q '^assistant' && "$0" assistant
  fi
  eww active-windows | grep -q '^launchpad' && eww close launchpad
  eww open "$w"; sleep 0.04; eww update ${w}_open=true
fi
