#!/usr/bin/env bash
# Control Center + menu bar backend
mode(){ cat ~/.cache/aurora-perf-mode 2>/dev/null || echo balanced; }
dnd(){ makoctl mode 2>/dev/null | grep -q do-not-disturb && echo true || echo false; }
dark(){ t=$(jq -r '.theme // "aurora"' ~/.config/aurora/settings.json 2>/dev/null); [ "$t" = light ] && echo false || echo true; }
kbdled(){ brightnessctl -l -m 2>/dev/null | grep -m1 kbd_backlight | cut -d, -f1; }
refresh(){ eww update cc="$("$0" status)" status="$("$0" bar)" 2>/dev/null; }
case "$1" in
  status)
    wifi=$(nmcli -t radio wifi 2>/dev/null)
    ssid=$(nmcli -t -f active,ssid dev wifi 2>/dev/null | awk -F: '$1=="yes"{print $2;exit}')
    bt=$(bluetoothctl show 2>/dev/null | grep -q "Powered: yes" && echo true || echo false)
    night=$( (pgrep -x gammastep || pgrep -x hyprsunset) >/dev/null && echo true || echo false)
    air=$(nmcli -t radio all 2>/dev/null | grep -q enabled && echo false || echo true)
    vol=$(wpctl get-volume @DEFAULT_AUDIO_SINK@ 2>/dev/null | awk '{print int($2*100)}')
    bri=$(brightnessctl -m 2>/dev/null | cut -d, -f4 | tr -d %)
    k=$(kbdled); kbd=false; haskbd=false
    if [ -n "$k" ]; then haskbd=true; [ "$(brightnessctl -d "$k" g 2>/dev/null)" -gt 0 ] 2>/dev/null && kbd=true; fi
    jq -nc --argjson w "$([ "$wifi" = enabled ] && echo true || echo false)" --arg s "${ssid:-Connected}" \
      --argjson b "$bt" --argjson n "$night" --argjson a "$air" --argjson d "$(dnd)" --argjson dk "$(dark)" \
      --argjson kb "$kbd" --argjson hk "$haskbd" --argjson v "${vol:-50}" --argjson br "${bri:-100}" --arg m "$(mode)" \
      '{wifi:$w,ssid:$s,bt:$b,night:$n,air:$a,dnd:$d,dark:$dk,kbd:$kb,haskbd:$hk,vol:$v,bri:$br,mode:$m}' ;;
  bar)
    wifi=$(nmcli -t radio wifi 2>/dev/null)
    bt=$(bluetoothctl show 2>/dev/null | grep -q "Powered: yes" && echo true || echo false)
    read -r _ v m <<<"$(wpctl get-volume @DEFAULT_AUDIO_SINK@ 2>/dev/null)"
    vol=$(awk -v v="${v:-0.5}" 'BEGIN{print int(v*100)}'); mute=$([ -n "$m" ] && echo true || echo false)
    bat=""; lvl=100; chg=false
    for b in /sys/class/power_supply/BAT*; do
      [ -r "$b/capacity" ] || continue
      lvl=$(cat "$b/capacity"); bat="${lvl}%"; grep -qi '^charging' "$b/status" 2>/dev/null && chg=true
    done
    jq -nc --argjson w "$([ "$wifi" = enabled ] && echo true || echo false)" --argjson b "$bt" --argjson v "$vol" \
      --argjson mu "$mute" --arg m "$(mode)" --arg bt "$bat" --argjson l "$lvl" --argjson c "$chg" \
      '{wifi:$w,bt:$b,vol:$v,mute:$mu,mode:$m,bat:$bt,batlvl:$l,charging:$c}' ;;
  wifi)  [ "$(nmcli -t radio wifi)" = enabled ] && nmcli radio wifi off || nmcli radio wifi on; refresh ;;
  bt)    if bluetoothctl show | grep -q "Powered: yes"; then bluetoothctl power off; else rfkill unblock bluetooth; bluetoothctl power on; fi; refresh ;;
  dnd)   makoctl mode -t do-not-disturb >/dev/null; refresh ;;
  dark)  [ "$(dark)" = true ] && aurora-apply set theme light || aurora-apply set theme aurora; refresh ;;
  night) if pgrep -x gammastep >/dev/null || pgrep -x hyprsunset >/dev/null; then pkill -x gammastep; pkill -x hyprsunset
         else setsid -f sh -c 'command -v hyprsunset >/dev/null && exec hyprsunset -t 4300 || exec gammastep -O 4300' >/dev/null 2>&1; fi
         sleep 0.3; refresh ;;
  air)   if nmcli -t radio all | grep -q enabled; then nmcli radio all off; rfkill block bluetooth
         else nmcli radio all on; rfkill unblock bluetooth; fi; refresh ;;
  kbd)   k=$(kbdled); [ -z "$k" ] && { notify-send -a Aurora "No keyboard backlight on this computer"; exit; }
         [ "$(brightnessctl -d "$k" g)" -gt 0 ] && brightnessctl -d "$k" set 0 >/dev/null || brightnessctl -d "$k" set 100% >/dev/null; refresh ;;
  gaming) [ "$(mode)" = gaming ] && aurora-perf balanced || aurora-perf gaming; refresh ;;
  eco)    [ "$(mode)" = eco ] && aurora-perf balanced || aurora-perf eco; refresh ;;
  vol)   v=${2%.*}; [ "$v" -gt 100 ] && v=100; wpctl set-volume @DEFAULT_AUDIO_SINK@ "$v%" ;;
  bri)   v=${2%.*}; [ "$v" -gt 100 ] && v=100; [ "$v" -lt 1 ] && v=1; brightnessctl set "$v%" >/dev/null ;;
esac
