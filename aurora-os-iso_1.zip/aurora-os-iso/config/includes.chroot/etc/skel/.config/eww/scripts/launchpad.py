#!/usr/bin/env python3
"""Aurora Launchpad backend.
  launchpad.py index                 rebuild ~/.cache/aurora-apps.json (apps + resolved icon files)
  launchpad.py show <cat> <query>    push matching rows to eww (6 per row)
  launchpad.py first <cat> <query>   print the desktop id of the first match
"""
import configparser, json, os, subprocess, sys

HOME = os.path.expanduser("~")
CACHE = os.path.join(HOME, ".cache/aurora-apps.json")
PER_ROW = 6
APP_DIRS = ["/usr/share/applications", "/usr/local/share/applications",
            os.path.join(HOME, ".local/share/applications"),
            "/var/lib/flatpak/exports/share/applications",
            os.path.join(HOME, ".local/share/flatpak/exports/share/applications")]
ICON_ROOTS = [os.path.join(HOME, ".local/share/icons"), os.path.join(HOME, ".icons"),
              "/usr/share/icons", "/var/lib/flatpak/exports/share/icons",
              os.path.join(HOME, ".local/share/flatpak/exports/share/icons")]
THEMES = ["Aurora", "WhiteSur-dark", "WhiteSur", "Papirus-Dark", "Papirus", "hicolor", "Adwaita"]
FALLBACK = os.path.join(HOME, ".config/eww/icons/app-apps.svg")

CATS = [  # (Aurora category, freedesktop categories)
    ("Games",         {"Game"}),
    ("Development",   {"Development", "IDE", "TextEditor"}),
    ("Creativity",    {"Graphics", "3DGraphics", "2DGraphics", "RasterGraphics", "VectorGraphics", "Photography", "AudioVideoEditing"}),
    ("Entertainment", {"AudioVideo", "Audio", "Video", "Player", "Music"}),
    ("Internet",      {"Network", "WebBrowser", "Email", "Chat", "InstantMessaging", "FileTransfer"}),
    ("Productivity",  {"Office", "Calendar", "WordProcessor", "Spreadsheet", "Presentation", "Finance", "ProjectManagement"}),
    ("Education",     {"Education", "Science", "Math", "Languages"}),
    ("Utilities",     {"Utility", "System", "Settings", "FileManager", "TerminalEmulator", "Accessories", "Archiving", "Monitor"}),
]

def category(cats):
    s = set(c for c in cats.split(";") if c)
    for name, keys in CATS:
        if s & keys:
            return name
    return "Others"

_icon_index = None
def icon_index():
    """name -> best file, preferring theme order, then scalable/svg, then the biggest size."""
    global _icon_index
    if _icon_index is not None:
        return _icon_index
    idx = {}
    def score(theme_rank, path):
        size = 0
        for part in path.split("/"):
            if part == "scalable": size = 10000
            elif "x" in part and part.split("x")[0].isdigit(): size = max(size, int(part.split("x")[0]))
            elif part.isdigit(): size = max(size, int(part))
        if path.endswith(".svg"): size += 5000
        return (-theme_rank, min(size, 15000))
    for root in ICON_ROOTS:
        for rank, theme in enumerate(THEMES):
            base = os.path.join(root, theme)
            if not os.path.isdir(base):
                continue
            for dp, _, files in os.walk(base):
                if "/apps" not in dp and "/places" not in dp:
                    continue
                if "symbolic" in dp:
                    continue
                for f in files:
                    if not f.endswith((".svg", ".png")):
                        continue
                    name = f.rsplit(".", 1)[0]
                    p = os.path.join(dp, f)
                    sc = score(rank, p)
                    if name not in idx or sc > idx[name][0]:
                        idx[name] = (sc, p)
    for f in os.listdir("/usr/share/pixmaps") if os.path.isdir("/usr/share/pixmaps") else []:
        name = f.rsplit(".", 1)[0]
        idx.setdefault(name, ((-99, 0), os.path.join("/usr/share/pixmaps", f)))
    _icon_index = {k: v[1] for k, v in idx.items()}
    return _icon_index

def resolve_icon(icon):
    if not icon:
        return FALLBACK
    if icon.startswith("/") and os.path.exists(icon):
        return icon
    return icon_index().get(icon) or icon_index().get(icon.lower()) or FALLBACK

def index():
    desktop = os.environ.get("XDG_CURRENT_DESKTOP", "Hyprland")
    seen, apps = set(), []
    for d in APP_DIRS:
        if not os.path.isdir(d):
            continue
        for f in sorted(os.listdir(d)):
            if not f.endswith(".desktop") or f in seen:
                continue
            cp = configparser.ConfigParser(interpolation=None, strict=False)
            try:
                cp.read(os.path.join(d, f), encoding="utf-8")
                e = cp["Desktop Entry"]
            except Exception:
                continue
            if e.get("Type", "Application") != "Application": continue
            if e.get("NoDisplay", "false").lower() == "true" or e.get("Hidden", "false").lower() == "true": continue
            only = e.get("OnlyShowIn", "")
            if only and desktop not in only.split(";"): continue
            if desktop in e.get("NotShowIn", "").split(";"): continue
            seen.add(f)
            apps.append({"id": f[:-8], "n": e.get("Name", f[:-8]),
                         "k": " ".join([e.get("GenericName", ""), e.get("Keywords", ""), e.get("Comment", "")]).lower(),
                         "c": category(e.get("Categories", "")),
                         "icon": resolve_icon(e.get("Icon", ""))})
    apps.sort(key=lambda a: a["n"].lower())
    os.makedirs(os.path.dirname(CACHE), exist_ok=True)
    json.dump(apps, open(CACHE, "w"), ensure_ascii=False)
    return apps

def load():
    """Use the cache; rebuild it when an app was installed or removed since."""
    try:
        t = os.path.getmtime(CACHE)
        if any(os.path.isdir(d) and os.path.getmtime(d) > t for d in APP_DIRS):
            return index()
        return json.load(open(CACHE))
    except Exception:
        return index()

def match(cat, query):
    q = (query or "").strip().lower()
    out = []
    for a in load():
        if cat not in ("", "All") and a["c"] != cat:
            continue
        if q and q not in a["n"].lower() and q not in a["k"] and q not in a["id"].lower():
            continue
        out.append(a)
    if q:  # names starting with the query first
        out.sort(key=lambda a: (not a["n"].lower().startswith(q), a["n"].lower()))
    return out

def show(cat, query):
    apps = match(cat, query)
    rows = [[{"id": a["id"], "n": a["n"], "c": a["c"], "icon": a["icon"]} for a in apps[i:i + PER_ROW]]
            for i in range(0, len(apps), PER_ROW)]
    subprocess.run(["eww", "update", f"lp_rows={json.dumps(rows, ensure_ascii=False)}",
                    f"lp_count={len(apps)}", f"lp_cat={cat or 'All'}"],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "show"
    cat = sys.argv[2] if len(sys.argv) > 2 else "All"
    query = sys.argv[3] if len(sys.argv) > 3 else ""
    if cmd == "index":
        print(len(index()), "apps")
    elif cmd == "first":
        m = match(cat, query)
        print(m[0]["id"] if m else "")
    else:
        show(cat, query)
