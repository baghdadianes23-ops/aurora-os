#!/usr/bin/env bash
# Quick notes: show (last lines, for the widget) | edit (opens the text editor)
F=~/.config/aurora/notes.txt
mkdir -p ~/.config/aurora; touch "$F"
case "$1" in
  show) grep -v '^\s*$' "$F" | tail -n 5 | cut -c1-60 ;;
  edit) (command -v mousepad >/dev/null && mousepad "$F" || kitty -e nano "$F") >/dev/null 2>&1 ;;
esac
