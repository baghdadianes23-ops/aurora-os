#!/usr/bin/env bash
# Launchpad controller: toggle | close | cat <name> | search <text> | first | run <desktop-id>
P="python3 $HOME/.config/eww/scripts/launchpad.py"
STATE=~/.cache/aurora-lp; mkdir -p ~/.cache
cat_(){ cat "$STATE.cat" 2>/dev/null || echo All; }
q_(){ cat "$STATE.q" 2>/dev/null; }
case "$1" in
  toggle)
    if eww active-windows | grep -q '^launchpad'; then "$0" close; exit; fi
    echo All > "$STATE.cat"; : > "$STATE.q"
    eww active-windows | grep -q '^control' && ~/.config/eww/scripts/panel.sh control
    $P show All ""
    eww open launchpad ;;
  close)  eww close launchpad ;;
  cat)    echo "$2" > "$STATE.cat"; $P show "$2" "$(q_)" ;;
  search) printf '%s' "$2" > "$STATE.q"; $P show "$(cat_)" "$2" ;;
  first)  id=$($P first "$(cat_)" "$(q_)"); [ -n "$id" ] && "$0" run "$id" ;;
  run)    eww close launchpad; canberra-gtk-play -i dialog-information >/dev/null 2>&1 &
          setsid -f gtk-launch "$2" >/dev/null 2>&1 ;;
esac
