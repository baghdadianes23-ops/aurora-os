#!/usr/bin/env python3
"""Aurora desktop icons (section 4 of the design).
  desktop-icons.py listen        print a JSON grid whenever ~/Desktop changes (for eww)
  desktop-icons.py open <path>   open with the default app
  desktop-icons.py menu <path>   right-click menu (Open · Show in Files · Rename · Move to Trash)
"""
import json, os, subprocess, sys, time

HOME = os.path.expanduser("~")
ICONS = os.path.join(HOME, ".config/eww/icons")
ROWS, MAX = 4, 24

def desktop_dir():
    try:
        d = subprocess.run(["xdg-user-dir", "DESKTOP"], capture_output=True, text=True, timeout=2).stdout.strip()
        if d and os.path.isdir(d):
            return d
    except Exception:
        pass
    d = os.path.join(HOME, "Desktop"); os.makedirs(d, exist_ok=True)
    return d

EXT = {
    "ft-text":   ".txt .md .rtf .log .csv .ini .conf",
    "ft-pdf":    ".pdf",
    "ft-zip":    ".zip .rar .7z .tar .gz .xz .bz2 .zst .deb .iso",
    "ft-image":  ".png .jpg .jpeg .webp .gif .bmp .svg .heic",
    "ft-doc":    ".doc .docx .odt .xls .xlsx .ods .ppt .pptx .odp",
    "ft-design": ".psd .ai .xcf .kra .fig .blend .sketch .afdesign",
    "ft-video":  ".mp4 .mkv .webm .avi .mov",
    "ft-audio":  ".mp3 .flac .ogg .wav .m4a .opus",
    "ft-code":   ".py .js .ts .html .css .c .cpp .h .java .sh .json .yml .yaml .rs .go .php .cs",
    "ft-app":    ".desktop .appimage .exe",
}
LOOKUP = {e: k for k, v in EXT.items() for e in v.split()}

def icon_for(path, is_dir):
    if is_dir:
        return os.path.join(ICONS, "app-folder.svg")
    ext = os.path.splitext(path)[1].lower()
    kind = LOOKUP.get(ext, "ft-text")
    if kind == "ft-image" and ext != ".svg" and os.path.getsize(path) < 6_000_000:
        return path                                    # real picture as its own thumbnail
    return os.path.join(ICONS, f"app-{kind}.svg")

def grid():
    d = desktop_dir()
    items = []
    for name in os.listdir(d):
        if name.startswith("."):
            continue
        p = os.path.join(d, name)
        isdir = os.path.isdir(p)
        label = name
        if name.endswith(".desktop"):                  # launcher: show its Name=
            try:
                for l in open(p, encoding="utf-8", errors="ignore"):
                    if l.startswith("Name="):
                        label = l[5:].strip(); break
            except Exception:
                pass
        items.append((not isdir, name.lower(), {"n": label, "p": p, "i": icon_for(p, isdir)}))
    items.sort(key=lambda t: (t[0], t[1]))
    items = [t[2] for t in items[:MAX]]
    # column-major like a desktop: fill down, then the next column
    cols = [items[i:i + ROWS] for i in range(0, len(items), ROWS)]
    return cols

def listen():
    d = desktop_dir()
    last = None
    while True:
        try:
            stamp = (os.path.getmtime(d), len(os.listdir(d)))
        except FileNotFoundError:
            stamp = None
        if stamp != last:
            last = stamp
            print(json.dumps(grid(), ensure_ascii=False), flush=True)
        time.sleep(2)

def sh(*cmd):
    subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)

def open_(path):
    if path.endswith(".desktop"):
        sh("gio", "launch", path)
    else:
        sh("xdg-open", path)

def menu(path):
    items = "Open\nShow in Files\nRename…\nMove to Trash"
    r = subprocess.run(["fuzzel", "--dmenu", "--lines", "4", "--width", "22", "--prompt", os.path.basename(path)[:18] + "  "],
                       input=items, capture_output=True, text=True).stdout.strip()
    if r == "Open":
        open_(path)
    elif r == "Show in Files":
        sh("thunar", "--select", path) if os.path.exists(path) else None
    elif r.startswith("Rename"):
        new = subprocess.run(["fuzzel", "--dmenu", "--lines", "0", "--width", "40", "--prompt", "New name:  "],
                             input="", capture_output=True, text=True).stdout.strip()
        if new and "/" not in new:
            dst = os.path.join(os.path.dirname(path), new)
            if not os.path.exists(dst):
                os.rename(path, dst)
    elif r == "Move to Trash":
        subprocess.run(["gio", "trash", path])
        sh("canberra-gtk-play", "-i", "trash-empty")

if __name__ == "__main__":
    a = sys.argv[1:] or ["listen"]
    if a[0] == "listen":
        listen()
    elif a[0] == "open" and len(a) > 1:
        open_(a[1])
    elif a[0] == "menu" and len(a) > 1:
        menu(a[1])
    elif a[0] == "once":
        print(json.dumps(grid(), ensure_ascii=False))
