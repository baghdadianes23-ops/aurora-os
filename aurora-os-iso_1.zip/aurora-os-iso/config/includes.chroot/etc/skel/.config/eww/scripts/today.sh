#!/usr/bin/env bash
# To-do backend.  ~/.config/aurora/today.txt  lines:  Title|09:00 - 11:00|#color|x(done)
#   today.sh list | toggle <i> | add
F=~/.config/aurora/today.txt
mkdir -p ~/.config/aurora; touch "$F"
case "$1" in
  list)
    grep -vE '^\s*(#|$)' "$F" | head -6 | awk -F'|' '{print NR-1 "|" $0}' | while IFS='|' read -r i t h c d; do
      jq -nc --argjson i "$i" --arg t "$t" --arg h "$h" --arg c "${c:-#B3A6FF}" --argjson d "$([ "$d" = x ] && echo true || echo false)" \
        '{i:$i,title:$t,time:$h,color:$c,done:$d}'
    done | jq -sc . ;;
  toggle)
    n=$(( $2 + 1 ))
    awk -F'|' -v OFS='|' -v n="$n" '
      /^[[:space:]]*(#|$)/ {print; next}
      {k++} k==n { while (NF<4) $(NF+1)=""; $4 = ($4=="x") ? "" : "x"; if ($4=="x") system("canberra-gtk-play -i complete >/dev/null 2>&1 &") }
      {print}' "$F" > "$F.tmp" && mv "$F.tmp" "$F"
    eww update today="$("$0" list)" ;;
  add)
    t=$(fuzzel --dmenu --lines 0 --width 40 --prompt "New task:  " < /dev/null)
    [ -z "$t" ] && exit
    h=$(printf "No time\n08:00 - 09:00\n09:00 - 11:00\n11:00 - 12:00\n14:00 - 16:00\n16:00 - 18:00\n19:00 - 20:30" \
        | fuzzel --dmenu --lines 7 --width 30 --prompt "Time:  ")
    [ "$h" = "No time" ] && h=""
    colors=("#8ADAE3" "#B3A6FF" "#FFD166" "#6CE675" "#FF9D6E" "#FF6B6B")
    c=${colors[$(( $(grep -cvE '^\s*(#|$)' "$F") % 6 ))]}
    printf '%s|%s|%s|\n' "${t//|/-}" "$h" "$c" >> "$F"
    eww update today="$("$0" list)" ;;
esac
