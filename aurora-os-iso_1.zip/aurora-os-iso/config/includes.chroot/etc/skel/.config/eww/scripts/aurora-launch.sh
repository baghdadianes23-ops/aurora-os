#!/usr/bin/env bash
# ============================================================
#  (Re)start the Aurora shell and open the widgets that fit this screen.
#  User choices (Aurora Settings → Desktop & Widgets) live in
#  ~/.config/aurora/settings.json → "widgets": {"music": true, ...}
# ============================================================
SET=~/.config/aurora/settings.json
pkill -f "eww.*daemon" 2>/dev/null; eww kill 2>/dev/null; sleep 0.4
eww daemon
for i in $(seq 1 25); do eww ping >/dev/null 2>&1 && break; sleep 0.2; done

# ---- logical screen size (after scaling) ----
read -r W H < <(hyprctl monitors -j 2>/dev/null | jq -r '.[0] | "\((.width/.scale)|floor) \((.height/.scale)|floor)"')
W=${W:-1920}; H=${H:-1080}

# ---- defaults by screen size ----
if   [ "$W" -ge 1800 ] && [ "$H" -ge 1000 ]; then
  DEF="places logo weather music sysmon today assistant-card desk-icons"
elif [ "$W" -ge 1500 ]; then
  DEF="logo weather music sysmon assistant-mini desk-icons"
else                                               # 1366x768 laptops, tablets
  DEF="logo weather music sysmon desk-icons"
fi

# ---- apply user overrides ----
want=" $DEF "
if [ -f "$SET" ]; then
  while IFS='=' read -r k v; do
    [ -z "$k" ] && continue
    case "$k" in assistant) k=$([ "$H" -ge 1000 ] && echo assistant-card || echo assistant-mini);; esac
    if [ "$v" = true ]; then [[ "$want" == *" $k "* ]] || want="$want$k "
    else want=${want// $k / }; [ "$k" = assistant-card ] && want=${want// assistant-mini / }; fi
  done < <(jq -r '.widgets // {} | to_entries[] | "\(.key)=\(.value)"' "$SET" 2>/dev/null)
fi
# desktop icons: compact position on small screens
if [ "$W" -lt 1800 ]; then want=${want// desk-icons / desk-icons-s }; fi
# weather moves right when the Places sidebar is shown
if [[ "$want" == *" places "* && "$want" == *" weather "* ]]; then want=${want// weather / weather-r }; fi

# ---- dock ----
pos=$(jq -r '.dock.position // "bottom"' "$SET" 2>/dev/null)
size=$(jq -r '.dock.size // empty' "$SET" 2>/dev/null)
[ -z "$size" ] && { [ "$H" -lt 900 ] && size=44 || size=52; }
glass=$(jq -r 'if .dock.glass == false then "false" else "true" end' "$SET" 2>/dev/null || echo true)
eww update dock_size="$size" dock_glass="$glass" \
  ai_engine="$(grep -Po '^engine=\K.*' ~/.config/aurora/ai.conf 2>/dev/null || echo ollama)"
[ "$pos" = left ] && DOCK=dock-left || DOCK=dock

# shellcheck disable=SC2086
eww open-many bar $want $DOCK
# warm the Launchpad icon cache in the background
(python3 ~/.config/eww/scripts/launchpad.py index >/dev/null 2>&1 &)
