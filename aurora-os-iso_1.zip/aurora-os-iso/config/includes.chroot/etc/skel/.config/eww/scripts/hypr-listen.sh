#!/usr/bin/env bash
# Event-driven Hyprland listener (no polling):  workspaces | dock | app
SOCK="$XDG_RUNTIME_DIR/hypr/$HYPRLAND_INSTANCE_SIGNATURE/.socket2.sock"
DOCK_CFG=~/.config/aurora/dock.json

workspaces() {
  local act occ
  act=$(hyprctl activeworkspace -j | jq '.id')
  occ=$(hyprctl workspaces -j | jq -c '[.[] | select(.windows > 0 and .id > 0) | .id]')
  jq -nc --argjson a "${act:-1}" --argjson o "${occ:-[]}" \
    '[range(1;6) as $i | {id:$i, active:($i==$a), occupied:($o|index($i) != null)}]'
}
dock() {
  local run foc live=false
  run=$(hyprctl clients -j 2>/dev/null | jq -c '[.[].class | ascii_downcase]')
  foc=$(hyprctl activewindow -j 2>/dev/null | jq -r '.class // "" | ascii_downcase')
  [ -d /run/live/medium ] && live=true
  jq -c --argjson r "${run:-[]}" --arg f "$foc" --argjson live "$live" '
    [ .[] | select((.liveonly // false) == false or $live)
      | . + {sep: (.sep // false),
             running: ([.class|ascii_downcase] | inside($r)),
             focused: ((.class|ascii_downcase) == $f)} ]' "$DOCK_CFG"
}
app() {   # pretty name of the focused application for the menu bar
  local c
  c=$(hyprctl activewindow -j 2>/dev/null | jq -r '.class // ""')
  [ -z "$c" ] && { echo "Desktop"; return; }
  n=$(jq -r --arg c "${c,,}" '.[] | select((.class|ascii_downcase)==$c) | .name' "$DOCK_CFG" 2>/dev/null | head -1)
  if [ -z "$n" ]; then
    case "${c,,}" in
      thunar) n=Files;; kitty|foot|alacritty) n=Terminal;; firefox*|org.mozilla.firefox) n=Firefox;;
      aurora-settings|os.aurora.settings) n=Settings;; steam*) n=Steam;; code|code-oss) n="Visual Studio Code";;
      *) n=${c##*.}; n=${n^};;
    esac
  fi
  echo "${n:0:22}"
}

"$1"
socat -U - UNIX-CONNECT:"$SOCK" 2>/dev/null | while read -r ev; do
  case "$1:${ev%%>>*}" in
    workspaces:workspace|workspaces:workspacev2|workspaces:openwindow|workspaces:closewindow|workspaces:movewindow|workspaces:movewindowv2|workspaces:focusedmon) workspaces ;;
    dock:openwindow|dock:closewindow|dock:activewindow) dock ;;
    app:activewindow|app:closewindow) app ;;
  esac
done
