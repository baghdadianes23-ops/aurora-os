#!/usr/bin/env bash
# music.sh listen  -> JSON stream on every track/status change
# music.sh pos     -> {pos,left,pct}
COVER=~/.cache/aurora-cover.png
emit(){
  st=$(playerctl status 2>/dev/null)
  if [ -z "$st" ]; then jq -nc '{title:"Nothing playing",artist:"Open a music app",status:"Stopped",cover:""}'; return; fi
  url=$(playerctl metadata mpris:artUrl 2>/dev/null)
  if [ -n "$url" ] && [ "$url" != "$(cat ~/.cache/aurora-cover.url 2>/dev/null)" ]; then
    echo "$url" > ~/.cache/aurora-cover.url
    case "$url" in file://*) cp "${url#file://}" ~/.cache/aurora-cover.src;; http*) curl -sf -o ~/.cache/aurora-cover.src "$url";; esac
    magick ~/.cache/aurora-cover.src -resize 140x140^ -gravity center -extent 140x140 "$COVER" 2>/dev/null \
      || convert ~/.cache/aurora-cover.src -resize 140x140^ -gravity center -extent 140x140 "$COVER" 2>/dev/null
  fi
  jq -nc --arg t "$(playerctl metadata title 2>/dev/null)" --arg a "$(playerctl metadata artist 2>/dev/null)" \
    --arg s "$st" --arg c "$([ -f "$COVER" ] && echo "$COVER")" '{title:$t,artist:$a,status:$s,cover:$c}'
}
fmt(){ s=${1%.*}; s=${s:-0}; printf '%d:%02d' $((s/60)) $((s%60)); }
case "$1" in
  listen) mkdir -p ~/.cache; emit
          playerctl -F metadata --format '{{status}}{{title}}' 2>/dev/null | while read -r _; do emit; done ;;
  pos) l=$(playerctl metadata mpris:length 2>/dev/null); p=$(playerctl position 2>/dev/null); p=${p%.*}; p=${p:-0}
       if [ -n "$l" ] && [ "$l" -gt 0 ]; then L=$((l/1000000)); echo "{\"pos\":\"$(fmt $p)\",\"left\":\"-$(fmt $((L-p)))\",\"pct\":$((p*100/L))}"
       else echo '{"pos":"0:00","left":"-0:00","pct":0}'; fi ;;
esac
