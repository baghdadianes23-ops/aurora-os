#!/usr/bin/env bash
ch=$(printf "  Lock\n  Log out\n  Restart\n  Shut down\n  Suspend" | fuzzel --dmenu --prompt "Power  " --lines 5 --width 22)
case "$ch" in
  *Lock*)    hyprlock ;;
  *Log*)     canberra-gtk-play -i desktop-logout; hyprctl dispatch exit ;;
  *Restart*) systemctl reboot ;;
  *Shut*)    canberra-gtk-play -i desktop-logout; systemctl poweroff ;;
  *Suspend*) systemctl suspend ;;
esac
