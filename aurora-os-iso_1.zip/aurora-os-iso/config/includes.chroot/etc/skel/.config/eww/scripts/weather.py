#!/usr/bin/env python3
"""Aurora weather (Open-Meteo: free, no API key).
City from ~/.config/aurora/city. Prints one JSON line for eww:
{temp, desc, city, icon, hours:[{t,icon,temp}], days:[{d,icon,max,min}]}"""
import json, os, time, urllib.parse, urllib.request

HOME = os.path.expanduser("~")
CITYF = os.path.join(HOME, ".config/aurora/city")
CACHE = os.path.join(HOME, ".cache/aurora-weather.json")
GEO = os.path.join(HOME, ".cache/aurora-geo.json")

CODES = {0: ("Clear", "☀", "☾"), 1: ("Mainly clear", "☀", "☾"), 2: ("Partly cloudy", "⛅", "☁"),
         3: ("Overcast", "☁", "☁"), 45: ("Fog", "≋", "≋"), 48: ("Fog", "≋", "≋"),
         51: ("Drizzle", "☂", "☂"), 53: ("Drizzle", "☂", "☂"), 55: ("Drizzle", "☂", "☂"),
         61: ("Rain", "☂", "☂"), 63: ("Rain", "☂", "☂"), 65: ("Heavy rain", "☂", "☂"),
         66: ("Freezing rain", "☂", "☂"), 67: ("Freezing rain", "☂", "☂"),
         71: ("Snow", "❄", "❄"), 73: ("Snow", "❄", "❄"), 75: ("Heavy snow", "❄", "❄"), 77: ("Snow", "❄", "❄"),
         80: ("Showers", "☂", "☂"), 81: ("Showers", "☂", "☂"), 82: ("Heavy showers", "☂", "☂"),
         85: ("Snow showers", "❄", "❄"), 86: ("Snow showers", "❄", "❄"),
         95: ("Thunderstorm", "⚡", "⚡"), 96: ("Thunderstorm", "⚡", "⚡"), 99: ("Thunderstorm", "⚡", "⚡")}

def code(c, day=True):
    d, i_day, i_night = CODES.get(int(c), ("—", "☁", "☁"))
    return d, (i_day if day else i_night)

def get(url):
    with urllib.request.urlopen(url, timeout=10) as r:
        return json.load(r)

def geo(city):
    try:
        g = json.load(open(GEO))
        if g.get("q") == city:
            return g
    except Exception:
        pass
    r = get("https://geocoding-api.open-meteo.com/v1/search?count=1&language=en&name=" + urllib.parse.quote(city))
    p = r["results"][0]
    g = {"q": city, "lat": p["latitude"], "lon": p["longitude"],
         "name": f'{p["name"]}, {p.get("country", "")}'.strip(", ")}
    json.dump(g, open(GEO, "w"))
    return g

def main():
    os.makedirs(os.path.dirname(CACHE), exist_ok=True)
    try:
        city = open(CITYF).read().strip() or "Algiers"
    except FileNotFoundError:
        city = "Algiers"
    try:
        g = geo(city)
        w = get("https://api.open-meteo.com/v1/forecast?" + urllib.parse.urlencode({
            "latitude": g["lat"], "longitude": g["lon"], "timezone": "auto", "forecast_days": 6,
            "current": "temperature_2m,weather_code,is_day",
            "hourly": "temperature_2m,weather_code,is_day",
            "daily": "weather_code,temperature_2m_max,temperature_2m_min"}))
        cur = w["current"]
        desc, icon = code(cur["weather_code"], cur.get("is_day", 1) == 1)
        now = cur["time"][:13]                       # "YYYY-MM-DDTHH"
        H = w["hourly"]
        start = next((i for i, t in enumerate(H["time"]) if t[:13] > now), 0)
        hours = []
        for i in range(start, min(start + 8, len(H["time"])), 2):   # every 2 hours, 4 slots
            hours.append({"t": H["time"][i][11:16], "icon": code(H["weather_code"][i], H["is_day"][i] == 1)[1],
                          "temp": f'{round(H["temperature_2m"][i])}°'})
        D = w["daily"]
        days = []
        for i in range(min(5, len(D["time"]))):
            t = time.strptime(D["time"][i], "%Y-%m-%d")
            days.append({"d": "Today" if i == 0 else time.strftime("%a", t),
                         "icon": code(D["weather_code"][i])[1],
                         "max": round(D["temperature_2m_max"][i]), "min": round(D["temperature_2m_min"][i])})
        out = {"temp": round(cur["temperature_2m"]), "desc": desc, "city": g["name"], "icon": icon,
               "hours": hours[:4], "days": days}
        json.dump(out, open(CACHE, "w"), ensure_ascii=False)
    except Exception:
        try:
            out = json.load(open(CACHE))
        except Exception:
            out = {"temp": "--", "desc": "Offline", "city": city, "icon": "☁", "hours": [], "days": []}
    print(json.dumps(out, ensure_ascii=False))

if __name__ == "__main__":
    main()
