#!/usr/bin/env bash
# dock.sh click <class> <command>: restore if minimized, focus if open, otherwise launch
cls=${1,,}
addr=$(hyprctl clients -j | jq -r --arg c "$cls" '[.[] | select((.class|ascii_downcase)==$c)][0].address // empty')
if [ -n "$addr" ]; then
  ws=$(hyprctl clients -j | jq -r --arg a "$addr" '.[] | select(.address==$a) | .workspace.name')
  if [ "$ws" = "special:minimized" ]; then
    cur=$(hyprctl activeworkspace -j | jq -r .id)
    hyprctl dispatch movetoworkspace "$cur,address:$addr" >/dev/null
  fi
  hyprctl dispatch focuswindow "address:$addr" >/dev/null
else
  canberra-gtk-play -i dialog-information >/dev/null 2>&1 &
  setsid -f sh -c "$2" >/dev/null 2>&1
fi
