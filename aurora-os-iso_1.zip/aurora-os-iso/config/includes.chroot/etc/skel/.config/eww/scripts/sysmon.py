#!/usr/bin/env python3
"""Aurora System Monitor — reads /proc directly, emits one JSON line per second.
CPU from /proc/stat deltas, RAM from /proc/meminfo, disk via statvfs, GPU from sysfs/nvidia-smi."""
import json, os, glob, shutil, subprocess, time

def cpu_times():
    with open("/proc/stat") as f:
        v = list(map(int, f.readline().split()[1:]))
    idle = v[3] + v[4]                      # idle + iowait
    return idle, sum(v[:8])

def mem():
    m = {}
    with open("/proc/meminfo") as f:
        for line in f:
            k, val = line.split(":")
            m[k] = int(val.split()[0])      # kB
    total, avail = m["MemTotal"], m["MemAvailable"]
    used = total - avail
    return round(used * 100 / total, 1), f"{used/1048576:.1f} / {total/1048576:.1f} GB"

def disk():
    s = os.statvfs("/")
    total = s.f_blocks * s.f_frsize
    used = (s.f_blocks - s.f_bfree) * s.f_frsize
    return round(used * 100 / total, 1), f"{used/1e9:.0f} / {total/1e9:.0f} GB"

NV = shutil.which("nvidia-smi")
AMD = glob.glob("/sys/class/drm/card*/device/gpu_busy_percent")
INTEL = glob.glob("/sys/class/drm/card*/gt_act_freq_mhz") or glob.glob("/sys/class/drm/card*/gt/gt0/rps_act_freq_mhz")
INTEL_MAX = glob.glob("/sys/class/drm/card*/gt_max_freq_mhz") or glob.glob("/sys/class/drm/card*/gt/gt0/rps_max_freq_mhz")

def gpu_name():
    try:
        out = subprocess.run(["lspci"], capture_output=True, text=True, timeout=3).stdout
        for l in out.splitlines():
            if "VGA" in l or "3D controller" in l:
                n = l.split(": ", 1)[1]
                for k in ("NVIDIA", "AMD", "Intel", "VMware", "VirtualBox", "Red Hat", "QXL"):
                    if k.lower() in n.lower():
                        return k if k not in ("Red Hat", "QXL") else "Virtual GPU"
                return n[:18]
    except Exception:
        pass
    return "GPU"

def gpu():
    try:
        if NV:
            o = subprocess.run([NV, "--query-gpu=utilization.gpu", "--format=csv,noheader,nounits"],
                               capture_output=True, text=True, timeout=2).stdout.split()
            return float(o[0]) if o else 0
        if AMD:
            return float(open(AMD[0]).read())
        if INTEL and INTEL_MAX:   # frequency based approximation for Intel iGPU
            a, m = float(open(INTEL[0]).read()), float(open(INTEL_MAX[0]).read())
            return round(a * 100 / m, 1) if m else 0
    except Exception:
        pass
    return 0

def net_bytes():
    rx = tx = 0
    with open("/proc/net/dev") as f:
        for line in f.readlines()[2:]:
            name, data = line.split(":", 1)
            if name.strip() == "lo":
                continue
            d = data.split(); rx += int(d[0]); tx += int(d[8])
    return rx + tx

def human(b):
    for u in ("B/s", "KB/s", "MB/s", "GB/s"):
        if b < 1024: return f"{b:.0f} {u}"
        b /= 1024
    return f"{b:.1f} TB/s"

def main():
    try:
        tier = open(os.path.expanduser("~/.config/aurora/tier")).read().strip()
    except Exception:
        tier = "full"
    step = 2 if tier == "lite" else 1
    cores = os.cpu_count() or 1
    name = gpu_name()
    pi, pt = cpu_times(); pn = net_bytes(); tick = 0
    d, dtxt = disk(); g = gpu()
    while True:
        time.sleep(step)
        i, t = cpu_times()
        cpu = 0.0 if t == pt else round((1 - (i - pi) / (t - pt)) * 100, 1)
        pi, pt = i, t
        n = net_bytes(); rate = n - pn; pn = n
        ram, rtxt = mem()
        tick += 1
        if tick % 10 == 0: d, dtxt = disk()     # disk changes slowly
        if tick % 2 == 0:  g = gpu()            # gpu every 2s (nvidia-smi is heavy)
        print(json.dumps({"cpu": cpu, "cores": cores, "ram": ram, "ramtxt": rtxt, "disk": d,
                          "disktxt": dtxt, "gpu": g, "gpuname": name, "net": human(rate)}), flush=True)

if __name__ == "__main__":
    main()
