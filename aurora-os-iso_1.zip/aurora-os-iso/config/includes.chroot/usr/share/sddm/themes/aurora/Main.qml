// Aurora OS — SDDM login (Qt5/Qt6 compatible, QtQuick only)
import QtQuick 2.15
import SddmComponents 2.0

Rectangle {
    id: root
    width: 1920; height: 1080
    color: "#0d0b24"
    property real s: Math.min(width / 1920, height / 1080)   // scale to any resolution
    property int sessionIdx: sessionModel.lastIndex
    property int userIdx: userModel.lastIndex >= 0 ? userModel.lastIndex : 0

    TextConstants { id: textConstants }

    Connections {
        target: sddm
        function onLoginFailed() { errorText.text = "Wrong password"; password.text = ""; shake.start() }
    }

    Image { anchors.fill: parent; source: "background.png"; fillMode: Image.PreserveAspectCrop; smooth: true }

    // clock (top)
    Column {
        anchors.horizontalCenter: parent.horizontalCenter
        y: 70 * s; spacing: 4 * s
        Text { id: clock; anchors.horizontalCenter: parent.horizontalCenter
               color: "white"; font.family: "Inter"; font.weight: Font.Light; font.pixelSize: 84 * s
               text: Qt.formatTime(new Date(), "HH:mm") }
        Text { id: date; anchors.horizontalCenter: parent.horizontalCenter
               color: "#e9d5ff"; font.family: "Inter"; font.pixelSize: 20 * s
               text: Qt.formatDate(new Date(), "dddd, d MMMM") }
        Timer { interval: 1000; running: true; repeat: true
                onTriggered: { clock.text = Qt.formatTime(new Date(), "HH:mm"); date.text = Qt.formatDate(new Date(), "dddd, d MMMM") } }
    }

    // card content (the glass card itself is baked into background.png: 440x520 at center, +40 px)
    Item {
        id: card
        width: 440 * s; height: 520 * s
        anchors.centerIn: parent
        anchors.verticalCenterOffset: 40 * s

        SequentialAnimation { id: shake
            NumberAnimation { target: card; property: "anchors.horizontalCenterOffset"; to: -12; duration: 50 }
            NumberAnimation { target: card; property: "anchors.horizontalCenterOffset"; to: 12; duration: 50 }
            NumberAnimation { target: card; property: "anchors.horizontalCenterOffset"; to: -6; duration: 50 }
            NumberAnimation { target: card; property: "anchors.horizontalCenterOffset"; to: 0; duration: 50 }
        }

        Column {
            anchors.horizontalCenter: parent.horizontalCenter
            y: 46 * s; spacing: 18 * s; width: 330 * s

            // avatar orb
            Rectangle {
                width: 96 * s; height: width; radius: width / 2
                anchors.horizontalCenter: parent.horizontalCenter
                gradient: Gradient {
                    GradientStop { position: 0.0; color: "#c4b5fd" }
                    GradientStop { position: 0.55; color: "#8b5cf6" }
                    GradientStop { position: 1.0; color: "#22d3ee" }
                }
                border.color: "#55ffffff"; border.width: 1
                Image { anchors.centerIn: parent; source: "logo.svg"; width: 44 * s; height: 44 * s; sourceSize.width: 88; sourceSize.height: 88 }
            }

            // user name (click to switch user)
            Text {
                id: userName
                anchors.horizontalCenter: parent.horizontalCenter
                color: "white"; font.family: "Inter"; font.pixelSize: 22 * s; font.weight: Font.DemiBold
                property var names: []
                text: userModel.count > 0 ? (names[userIdx] || userModel.lastUser || "user") : "user"
                Repeater { model: userModel; Item { Component.onCompleted: { var n = userName.names; n[index] = (model.realName || model.name); userName.names = n } } }
                Repeater { model: userModel; Item { property string login: model.name; Component.onCompleted: logins.push(model.name) } }
                MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor
                            onClicked: if (userModel.count > 1) userIdx = (userIdx + 1) % userModel.count }
            }
            Text { anchors.horizontalCenter: parent.horizontalCenter; color: "#a5a0c8"
                   font.family: "Inter"; font.pixelSize: 12 * s; text: userModel.count > 1 ? "click the name to switch user" : "Welcome to Aurora OS" }

            // password field (16px rounded glass)
            Rectangle {
                width: parent.width; height: 50 * s; radius: 16 * s
                color: "#14ffffff"; border.width: 1
                border.color: password.activeFocus ? "#a78bfa" : "#30ffffff"
                Behavior on border.color { ColorAnimation { duration: 150 } }
                TextInput {
                    id: password
                    anchors.fill: parent; anchors.leftMargin: 18 * s; anchors.rightMargin: 56 * s
                    verticalAlignment: TextInput.AlignVCenter
                    echoMode: TextInput.Password; passwordCharacter: "●"
                    color: "white"; font.family: "Inter"; font.pixelSize: 16 * s
                    focus: true; clip: true
                    Keys.onReturnPressed: doLogin(); Keys.onEnterPressed: doLogin()
                    onTextChanged: errorText.text = ""
                    Text { visible: password.text.length === 0; anchors.verticalCenter: parent.verticalCenter
                           text: "Password"; color: "#8f89b8"; font: password.font }
                }
                Rectangle {   // login arrow
                    width: 38 * s; height: 38 * s; radius: 12 * s
                    anchors.right: parent.right; anchors.rightMargin: 6 * s; anchors.verticalCenter: parent.verticalCenter
                    gradient: Gradient { orientation: Gradient.Horizontal
                        GradientStop { position: 0; color: "#8b5cf6" } GradientStop { position: 1; color: "#22d3ee" } }
                    Text { anchors.centerIn: parent; text: "➜"; color: "white"; font.pixelSize: 18 * s }
                    MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: doLogin() }
                }
            }
            Text { id: errorText; anchors.horizontalCenter: parent.horizontalCenter; color: "#f9a8d4"
                   font.family: "Inter"; font.pixelSize: 13 * s; text: "" }

            // session selector
            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                color: "#c4b5fd"; font.family: "Inter"; font.pixelSize: 12 * s
                property var sess: []
                text: "Session:  " + (sess[sessionIdx] || "Hyprland") + "   ⌄"
                Repeater { model: sessionModel; Item { Component.onCompleted: { var a = parent.sess; a[index] = model.name; parent.sess = a } } }
                MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor
                            onClicked: sessionIdx = (sessionIdx + 1) % Math.max(1, sessionModel.count) }
            }
        }
    }

    property var logins: []
    function doLogin() {
        var u = logins.length > userIdx ? logins[userIdx] : userModel.lastUser
        sddm.login(u, password.text, sessionIdx)
    }

    // power buttons (bottom right)
    Row {
        anchors.right: parent.right; anchors.bottom: parent.bottom; anchors.margins: 36 * s
        spacing: 14 * s
        Repeater {
            model: [ { icon: "moon.svg", act: "suspend", ok: sddm.canSuspend },
                     { icon: "power.svg", act: "power", ok: sddm.canPowerOff } ]
            Rectangle {
                visible: modelData.ok
                width: 48 * s; height: 48 * s; radius: 16 * s
                color: hover.containsMouse ? "#40a78bfa" : "#1affffff"
                border.color: "#30ffffff"; border.width: 1
                Behavior on color { ColorAnimation { duration: 150 } }
                Image { anchors.centerIn: parent; source: modelData.icon; width: 20 * s; height: 20 * s; sourceSize.width: 48; sourceSize.height: 48 }
                MouseArea { id: hover; anchors.fill: parent; hoverEnabled: true; cursorShape: Qt.PointingHandCursor
                            onClicked: modelData.act === "power" ? sddm.powerOff() : sddm.suspend() }
            }
        }
    }
    Component.onCompleted: password.forceActiveFocus()
}
